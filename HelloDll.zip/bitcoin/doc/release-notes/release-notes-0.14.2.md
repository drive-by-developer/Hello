Bitcoin ABC version 0.14.2 is now available from:

  <https://download.bitcoinabc.org/0.14.2/>

This release includes various changes. The most notable is a change to the difficulty adjustment algorithm which decreases the difficulty in case the hashrate becomes very low. We obviously hope that this feature will not need to be used, and it would not kick in if the hashrate stays above 8% of the global hashrate. However, it ensures that this chain will survive no matter what, as long as someone thinks it is valuable.
