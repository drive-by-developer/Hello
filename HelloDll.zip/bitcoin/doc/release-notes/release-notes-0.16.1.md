Bitcoin ABC version 0.16.1 is now available from:

  <https://download.bitcoinabc.org/0.16.1/>

This release includes the following features and fixes:

- Update seeds
