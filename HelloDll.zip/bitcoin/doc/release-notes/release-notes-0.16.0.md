Bitcoin ABC version 0.16.0 is now available from:

  <https://download.bitcoinabc.org/0.16.0/>

This release includes the following features and fixes:

- New difficulty adjustement algorithm due to activate on Nov, 13
- Start enforcing LOW_S and NULLFAIL after Nov, 13
